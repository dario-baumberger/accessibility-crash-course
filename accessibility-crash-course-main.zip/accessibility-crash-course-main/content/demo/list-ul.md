# Unordered Lists

<ul>
    <li>List Item 1</li>
    <li>List Item 2</li>
    <li>List Item 3
        <ul>
            <li>List Item 3.1</li>
            <li>List Item 3.2</li>
            <li>List Item 3.3</li>
            <li>List Item 3.4</li>
        </ul>
    </li>
    <li>List Item 4</li>
</ul>

``` html
<ul>
    <li>List Item 1</li>
    <li>List Item 2</li>
    <li>List Item 3
        <ul>
            <li>List Item 3.1</li>
            <li>List Item 3.2</li>
            <li>List Item 3.3</li>
            <li>List Item 3.4</li>
        </ul>
    </li>
    <li>List Item 4</li>
</ul>
```
