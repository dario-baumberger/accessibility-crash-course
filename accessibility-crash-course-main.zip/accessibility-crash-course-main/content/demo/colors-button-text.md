# Button Colors with Text

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Good but strange
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Save</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Save</buton>
```
</div>
<div class="w-1/6">
	<p>
		Good but strange
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Delete</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Delete</buton>
```
</div>
</div>

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Delete</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Delete</buton>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Save</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Save</buton>
```
</div>
</div>