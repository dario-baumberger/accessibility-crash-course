# Link
<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<div onclick="window.location.href='/';">Klick mich</div>
</div>
<div class="w-3/6">

``` html
	<div onclick="window.location.href='/';">Klick mich</div>
```
</div>
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<div style="cursor: pointer; color: blue;" tabindex="0" onclick="window.location.href='/';">Klick mich</div>
</div>
<div class="w-3/6">

``` html
	<div style="cursor: pointer; color: blue;" tabindex="0" onclick="window.location.href='/';">Klick mich</div>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<a href="/">Klick mich</a>
</div>
<div class="w-3/6">

``` html
	<a href="/">Klick mich</a>
```
</div>
</div>
