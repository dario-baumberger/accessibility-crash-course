# Images
## Complex Content

<img src="<%- config.base %>/static/images/boerse.png" class="w-3/4" alt="Bild mit Börsendaten" />

<br />

```
<img src="<%- config.base %>/static/images/boerse.png" class="w-3/4" alt="Bild mit Börsendaten" />
```

---

Quellen:
- [https://www.boerse.de/](https://www.boerse.de/boersenwissen/grafiken/indizes)
