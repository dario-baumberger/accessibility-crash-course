# Image - Background Image

<div style="width: 500px; height: 500px; background-image: url('/static/images/monitor_november_cover_2019.gif');"></div>

<br>

``` html
<div style="width: 500px; height: 500px; background-image: url('/static/images/monitor_november_cover_2019.gif');"></div>
```
