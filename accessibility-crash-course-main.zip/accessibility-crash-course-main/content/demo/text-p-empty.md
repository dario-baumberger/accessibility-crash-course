# Text Semantic Paragraph with empty <p>
<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<p style="padding: 5px; background-color: blue; color: white;"></p>
</div>
<div class="w-3/6">

``` html
	<p style="padding: 5px; background-color: blue; color: white;"></p>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<p style="padding: 5px; background-color: blue; color: white;">Text</p>
</div>
<div class="w-3/6">

``` html
	<p style="padding: 5px; background-color: blue; color: white;">Text</p>
```
</div>
</div>
