# Table

<table>
	<tr>
		<th>Produkt</th>
		<th>Preis</th>
	</tr>
	<tr>
		<th>Gala Apfel</th>
		<td>CHF 0.85</td>
	</tr>
	<tr>
		<th>Gala Jazz</th>
		<td>CHF 0.90</td>
	</tr>
	<tr>
		<th>Gala Diwa</th>
		<td>CHF 0.90</td>
	</tr>
</table>

``` html
<table>
	<tr>
		<th>Produkt</th>
		<th>Preis</th>
	</tr>
	<tr>
		<th>Gala Apfel</th>
		<td>CHF 0.85</td>
	</tr>
	<tr>
		<th>Gala Jazz</th>
		<td>CHF 0.90</td>
	</tr>
	<tr>
		<th>Gala Diwa</th>
		<td>CHF 0.90</td>
	</tr>
</table>
```