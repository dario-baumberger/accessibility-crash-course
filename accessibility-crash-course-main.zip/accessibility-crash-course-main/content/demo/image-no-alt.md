# Images
## No Alternative Text

<img src="<%- config.base %>/static/images/1000.jpg" class="w-3/4" />

<br />

```
<img src="<%- config.base %>/static/images/1000.jpg" class="w-3/4" />
```
