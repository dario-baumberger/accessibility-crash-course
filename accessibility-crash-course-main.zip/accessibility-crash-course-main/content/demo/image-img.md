# Image - Img Image

<img src="<%- config.base %>/static/images/monitor_november_cover_2019.gif" />

<br>

``` html
<img src="<%- config.base %>/static/images/monitor_november_cover_2019.gif" />
```
