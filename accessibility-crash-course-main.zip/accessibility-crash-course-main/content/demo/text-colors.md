# Text Colors & Background Colors (Contrast)

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<p style="background-color: #efefef; color: #fff; display: inline-block;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="background-color: #efefef; color: #fff; display: inline-block;">lorem ipsum dolor</p>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<p style="background-color: #fff; color: #000; display: inline-block;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="background-color: #fff; color: #000; display: inline-block;">lorem ipsum dolor</p>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<p style="background-color: #000; color: #fff; display: inline-block;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="background-color: #000; color: #fff; display: inline-block;">lorem ipsum dolor</p>
```
</div>
</div>