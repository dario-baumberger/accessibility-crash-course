# Images
## With Alternative Text

<img src="<%- config.base %>/static/images/1000.jpg" class="w-3/4" alt="Spruch Ein Bild sagt mehr als 1000 Wort und 1000 zufällige Wörter" />

<br />

```
<img src="<%- config.base %>/static/images/1000.jpg" class="w-3/4" alt="Spruch Ein Bild sagt mehr als 1000 Wort und 1000 zufällige Wörter" />
```
