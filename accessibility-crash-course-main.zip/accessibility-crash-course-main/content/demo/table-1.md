# Table

<table>
	<tr>
		<th>Produkt</th>
		<th>Preis</th>
	</tr>
	<tr>
		<td>Gala Apfel</td>
		<td>CHF 0.85</td>
	</tr>
	<tr>
		<td>Gala Jazz</td>
		<td>CHF 0.90</td>
	</tr>
	<tr>
		<td>Gala Diwa</td>
		<td>CHF 0.90</td>
	</tr>
</table>

``` html
<table>
	<tr>
		<th>Produkt</th>
		<th>Preis</th>
	</tr>
	<tr>
		<td>Gala Apfel</td>
		<td>CHF 0.85</td>
	</tr>
	<tr>
		<td>Gala Jazz</td>
		<td>CHF 0.90</td>
	</tr>
	<tr>
		<td>Gala Diwa</td>
		<td>CHF 0.90</td>
	</tr>
</table>
```