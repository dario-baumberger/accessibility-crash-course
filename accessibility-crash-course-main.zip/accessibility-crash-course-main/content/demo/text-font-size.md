# Text Font Size

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<p style="font-size: 8px;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="font-size: 8px;">lorem ipsum dolor</p>
```
</div>
<div class="w-1/6">
	<p>
		Maybe not so good
	<p>
</div>
<div class="w-2/6">
	<p style="font-size: 12px;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="font-size: 12px;">lorem ipsum dolor</p>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<p style="font-size: 18px;">lorem ipsum dolor</p>
</div>
<div class="w-3/6">

``` html
	<p style="font-size: 18px;">lorem ipsum dolor</p>
```
</div>
</div>