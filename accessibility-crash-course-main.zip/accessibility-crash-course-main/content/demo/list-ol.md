# Ordered Lists

<ol class="list-decimal">
    <li>List Item 1</li>
    <li>List Item 2</li>
    <li>List Item 3
        <ol>
            <li>List Item 3.1</li>
            <li>List Item 3.2</li>
            <li>List Item 3.3</li>
            <li>List Item 3.4</li>
        </ol>
    </li>
    <li>List Item 4</li>
</ol>

``` html
<ol class="list-decimal">
    <li>List Item 1</li>
    <li>List Item 2</li>
    <li>List Item 3
        <ol>
            <li>List Item 3.1</li>
            <li>List Item 3.2</li>
            <li>List Item 3.3</li>
            <li>List Item 3.4</li>
        </ol>
    </li>
    <li>List Item 4</li>
</ol>
```
