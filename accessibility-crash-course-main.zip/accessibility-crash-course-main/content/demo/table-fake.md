# Table

<div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block; font-weight: bold;">Produkt</p>
		<p style="width: 50%; display: inline-block; font-weight: bold;">Preis</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Apfel</p>
		<p style="width: 50%; display: inline-block;">CHF 0.85</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Jazz</p>
		<p style="width: 50%; display: inline-block;">CHF 0.90</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Diwa</p>
		<p style="width: 50%; display: inline-block;">CHF 0.90</p>
	</div>
</div>

``` html
<div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block; font-weight: bold;">Produkt</p>
		<p style="width: 50%; display: inline-block; font-weight: bold;">Preis</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Apfel</p>
		<p style="width: 50%; display: inline-block;">CHF 0.85</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Jazz</p>
		<p style="width: 50%; display: inline-block;">CHF 0.90</p>
	</div>
	<div style="display: flex;">
		<p style="width: 50%; display: inline-block;">Gala Diwa</p>
		<p style="width: 50%; display: inline-block;">CHF 0.90</p>
	</div>
</div>
```