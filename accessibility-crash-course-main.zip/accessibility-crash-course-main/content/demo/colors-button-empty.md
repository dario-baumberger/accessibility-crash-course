# Button Colors

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: red; color: white;"></buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: red; color: white;"></buton>
```
</div>
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: green; color: white;"></buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: green; color: white;"></buton>
```
</div>
</div>
<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Text</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: red; color: black;">Text</buton>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Text</buton>
</div>
<div class="w-3/6">

``` html
	<button style="width: 100px; height: 40px; background-color: green; color: white;">Text</buton>
```
</div>
</div>