# Text Semantic Headings

<div class="flex flex-wrap">
<div class="w-1/6">
	<p>
		Bad
	<p>
</div>
<div class="w-2/6">
	<div style="font-size: 20px; font-weight: bold;">Ich bin ein Text in einem div</div>
</div>
<div class="w-3/6">

``` html
	<div style="font-size: 20px; font-weight: bold;">Ich bin ein Text in einem div</div>
```
</div>
<div class="w-1/6">
	<p>
		Good
	<p>
</div>
<div class="w-2/6">
	<h1 style="font-size: 20px; font-weight: bold;">Ich bin ein Text in einem h1</h1>
</div>
<div class="w-3/6">

``` html
	<h1 style="font-size: 20px; font-weight: bold;">Ich bin ein Text in einem h1</h1>
```
</div>
</div>